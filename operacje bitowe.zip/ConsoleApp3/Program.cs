﻿//zad 1

 static int CountSetBits(int number)
{
    int count = 0;

    while (number != 0)
    {
        count += number & 1;
        number >>= 1;
    }

    return count;
}


int result1 = CountSetBits(5);
Console.WriteLine(result1);


//zad 2

 static bool IsPowerOfTwo(int number)
{
    return (number != 0 && (number & (number - 1)) == 0);
}


bool result2 = IsPowerOfTwo(8);
Console.WriteLine(result2);


//zad 3

 static int ReverseBits(int number)
{
    int result = 0;  
    int bitCount = 32; 

    for (int i = 0; i < bitCount; i++)
    {
        
        result <<= 1;

       
        int bit = number & 1;

       
        result |= bit;

        
        number >>= 1;
    }

    return result;
}


int result3 =  ReverseBits(3);
Console.WriteLine(result3);


//zad 4

static int ToggleBit(int number, int position)
{
    return number ^ (1 << position);
}


int result4 = ToggleBit(5,1);
Console.WriteLine(result4);